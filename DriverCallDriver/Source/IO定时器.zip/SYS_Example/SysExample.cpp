#ifdef __cplusplus
extern "C"
{
#endif
#include <NTDDK.h>
#ifdef __cplusplus
}
#endif 

#include "../ZShareFiles/ZShareDef.h"

#define Debug(_X_)		{KdPrint(("SYS_Example,"));KdPrint((_X_)); KdPrint(("\n"));}

typedef struct _MyDeviceExtend
{
	long TimeCount;
	PIRP CurrentIrp;
}MyDeviceExtend;
NTSTATUS DispatchRoutine(IN PDEVICE_OBJECT pDevObj, IN PIRP pIrp) 
{
	Debug("Enter DispatchRoutine");
	pIrp->IoStatus.Status = STATUS_SUCCESS;
	pIrp->IoStatus.Information = 0;
	IoCompleteRequest( pIrp, IO_NO_INCREMENT );
	Debug("Leave DispatchRoutine");
	return STATUS_SUCCESS;
}

NTSTATUS DriverRead(IN PDEVICE_OBJECT pDevObj, IN PIRP pIrp) 
{
	Debug("Enter DriverRead");
	pIrp->IoStatus.Information	= 0;
	pIrp->IoStatus.Status		= STATUS_SUCCESS;
	IoCompleteRequest(pIrp,IO_NO_INCREMENT);	
	Debug("Leave DriverRead");
	return STATUS_SUCCESS;
}

VOID DriverUnload(IN PDRIVER_OBJECT DriverObject)
{
	PDEVICE_OBJECT tDevObj		= DriverObject->DeviceObject;
	MyDeviceExtend* tDevExtend	= (MyDeviceExtend*)tDevObj->DeviceExtension;
	IoStopTimer(tDevObj);

	while(NULL != tDevObj)
	{
		PDEVICE_OBJECT tNextDevObj	= tDevObj->NextDevice;
		UNICODE_STRING tSymbolicName;
		RtlInitUnicodeString(&tSymbolicName,DEVICE_SYMBOLICLINK);
		IoDeleteSymbolicLink(&tSymbolicName);
		IoDeleteDevice(tDevObj);
		tDevObj = tNextDevObj;
	}
}

void OnTime(IN PDEVICE_OBJECT DeviceObject, IN PVOID Context)
{
	Debug("Enter OnTime");
	
	const int Times = 4;
	MyDeviceExtend* tDevExtend	= (MyDeviceExtend*)DeviceObject->DeviceExtension;
	InterlockedIncrement(&tDevExtend->TimeCount);
	InterlockedCompareExchange(&tDevExtend->TimeCount,0,Times);
	if(0 == tDevExtend->TimeCount)
		Debug("lalalalalallala");
}

extern "C" NTSTATUS DriverEntry(IN PDRIVER_OBJECT pDriverObject, IN PUNICODE_STRING pRegistryPath) 
{
	Debug(("Enter DriverEntry\n"));

	pDriverObject->DriverUnload = DriverUnload;
	pDriverObject->MajorFunction[IRP_MJ_CREATE]	= DispatchRoutine;
	pDriverObject->MajorFunction[IRP_MJ_CLOSE]	= DispatchRoutine;
	pDriverObject->MajorFunction[IRP_MJ_WRITE]	= DispatchRoutine;
	pDriverObject->MajorFunction[IRP_MJ_READ]	= DispatchRoutine;

	//�����豸
	PDEVICE_OBJECT tDev;
	UNICODE_STRING tDevName;
	RtlInitUnicodeString(&tDevName,DEVICE_NAME);

	NTSTATUS tRetStatus;
	tRetStatus = IoCreateDevice(pDriverObject,
								sizeof(MyDeviceExtend),
								&tDevName,
								FILE_DEVICE_UNKNOWN,
								0,
								FALSE,
								&tDev);

	if(false == NT_SUCCESS(tRetStatus))
	{
		Debug("IoCreateDevice fail");
		return tRetStatus;
	}

	//������������
	UNICODE_STRING tSymbolicName;
	RtlInitUnicodeString(&tSymbolicName,DEVICE_SYMBOLICLINK);
	tRetStatus = IoCreateSymbolicLink(&tSymbolicName,&tDevName);
	if(false == NT_SUCCESS(tRetStatus))
	{
		Debug("IoCreateSymbolicLink fail");
		IoDeleteDevice(tDev);
		return tRetStatus;
	}

	tDev->Flags |= DO_BUFFERED_IO;

	MyDeviceExtend* tMyDevExtend	= (MyDeviceExtend*)tDev->DeviceExtension;
	tMyDevExtend->TimeCount			= 0;

	IoInitializeTimer(tDev,OnTime,0);
	IoStartTimer(tDev);
	return STATUS_SUCCESS;
}